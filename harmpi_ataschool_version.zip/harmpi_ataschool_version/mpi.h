//
//  mpi.h
//  HARM2D
//
//  Created by Alexander Tchekhovskoy on 2/22/15.
//  Copyright (c) 2015. All rights reserved.
//

#ifndef __HARM2D__mpi__
#define __HARM2D__mpi__

#include <stdio.h>

#endif /* defined(__HARM2D__mpi__) */
