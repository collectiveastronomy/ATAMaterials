#!/bin/bash
#SBATCH -t 2:00:00
#SBATCH -n 4
#SBATCH -J torus2D
module load openmpi/gnu/mt/ilp64/2.0.4.3
srun ./harm 4 4 1
